# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 16:24:57 2013

@author: jnd
"""

# This class implements a thin wrapper around the ElementTree/Element classes, which does XML parsing/writing.
# This allows us change the implementation if we want, without having to rewrite the UI code.
# from xml.etree.ElementTree import ElementTree as ET, Element
import xml.etree.ElementTree as ET

import logging


class SLLSystemParameters():
    
    values_dict = {}
    
    def __init__(self):
        # Create the tree structure:
        self.logger = logging.getLogger("XEM_GUI3.SLLSystemParameters")

        self.logger.info("Creating instance of class SLLSystemParameters")

        self.root = ET.Element('SuperLaserLandPLL_settings')
        self.tree = ET.ElementTree(self.root)
        
        # Default values for all the parameters:
        self.root.append(ET.Element('Reference_frequency', DDC0='21.4e6', DDC1='21.4e6'))
        self.root.append(ET.Element('Beat_frequency_modulation_range', DAC0='3e8', DAC1='0.5e6', DAC2='9e6'))
        self.root.append(ET.Element('Output_limits_low', DAC0='0', DAC1='0', DAC2='0'))
        self.root.append(ET.Element('Output_limits_high', DAC0='8.0', DAC1='8', DAC2='100'))
        self.root.append(ET.Element('Input_Output_gain', ADC0='1', ADC1='1', DAC0='8', DAC1='8'))
        self.root.append(ET.Element('Output_offset_in_volts', DAC0='4.0', DAC1='2.5', DAC2='27'))
        self.root.append(ET.Element('PLL0_settings', kp='3.28e1', fi='7.59e4', fii='1e1', fd='1.38e5', fdf='3.63e5', chkKd='True', chkKp='True', chkLock='False', chkKpCrossing='True'))
        self.root.append(ET.Element('PLL1_settings', kp='-5.47e1', fi='2e5', fii='1e1', fd='6.46e4', fdf='8.71e4', chkKd='True', chkKp='True', chkLock='False', chkKpCrossing='True'))
        self.root.append(ET.Element('PLL2_settings', kp='-120', fi='1e-2', fii='0', fd='1', fdf='1', chkKd='False', chkKp='False', chkLock='False', chkKpCrossing='False'))
        
        self.root.append(ET.Element('PWM0_settings', standard='3.3', levels='256', default='0.0', minval='0.0', maxval='3.3'))
        
        
        self.root.append(ET.Element('Main_window_settings', refresh_delay='500', N_samples_adc='1.75e3', N_samples_ddc='1e6', Integration_limit='5e6'))
        return
        
    def loadFromFile(self, strFilename):
        self.logger.debug("Calling loadFromFile({})".format(strFilename))
        self.tree = ET.parse(strFilename)
        self.root = self.tree.getroot()
        return
    
    def saveToFile(self, strFilename):
        self.logger.debug("Calling saveToFile({})".format(strFilename))
        self.tree.write(strFilename)
        return        

    def getValue(self, strKey, strParameter):
        value = self.tree.find(strKey).attrib[strParameter]
        self.logger.debug("getValue(): strKey={}; strParameter={}; strValue={}".format(strKey, strParameter, value))
        return value
        
    def setValue(self, strKey, strParameter, strValue):
        self.logger.debug("setValue(): strKey={}; strParameter={}; strValue={}".format(strKey, strParameter, strValue))
        self.tree.find(strKey).attrib[strParameter] = strValue
        
    def sendToFPGA(self, sl, bSendToFPGA = True):
        self.logger.info("sendToFPGA(): Sending configuration to FPGA")
        # Set the programmable gain amplifiers values:
        # allowed values: 1, 2, 4, 8
        # adding DAC2...gain, maybe it doesnt have programmable gain
        ADC0_gain = int(self.getValue('Input_Output_gain', 'ADC0'))
        ADC1_gain = int(self.getValue('Input_Output_gain', 'ADC1'))
        DAC0_gain = int(self.getValue('Input_Output_gain', 'DAC0'))
        DAC1_gain = int(self.getValue('Input_Output_gain', 'DAC1'))

        self.logger.debug("ADC0_gain = {}".format(ADC0_gain))
        self.logger.debug("ADC1_gain = {}".format(ADC1_gain))
        self.logger.debug("DAC0_gain = {}".format(DAC0_gain))
        self.logger.debug("DAC1_gain = {}".format(DAC1_gain))

        self.logger.debug("Sending gain values to FPGA")
        sl.set_pga_gains(ADC0_gain, ADC1_gain, DAC0_gain, DAC1_gain, bSendToFPGA)
        
        # Set the DAC output limits:

        self.logger.debug("Calculating and sending DAC limits to FPGA")

        limit_low = float(self.getValue('Output_limits_low', 'DAC0'))    # the limit is in volts
        limit_high = float(self.getValue('Output_limits_high', 'DAC0'))    # the limit is in volts
        self.logger.debug("DAC0 lower limit={}; upper limit={}".format(limit_low, limit_high))
        sl.set_dac_limits(0, sl.convertDACVoltsToCounts(0, limit_low), sl.convertDACVoltsToCounts(0, limit_high), bSendToFPGA)

        limit_low = float(self.getValue('Output_limits_low', 'DAC1'))    # the limit is in volts
        limit_high = float(self.getValue('Output_limits_high', 'DAC1'))    # the limit is in volts
        self.logger.debug("DAC1 lower limit={}; upper limit={}".format(limit_low, limit_high))
        sl.set_dac_limits(1, sl.convertDACVoltsToCounts(1, limit_low), sl.convertDACVoltsToCounts(1, limit_high), bSendToFPGA)

        limit_low = float(self.getValue('Output_limits_low', 'DAC2'))    # the limit is in volts
        limit_high = float(self.getValue('Output_limits_high', 'DAC2'))    # the limit is in volts
        self.logger.debug("DAC2 lower limit={}; upper limit={}".format(limit_low, limit_high))
        sl.set_dac_limits(2, sl.convertDACVoltsToCounts(2, limit_low), sl.convertDACVoltsToCounts(2, limit_high), bSendToFPGA)
        
        ##
        ## HB, 4/27/2015, Added PWM support on DOUT0
        ##
        PWM0_standard = float(self.getValue('PWM0_settings', 'standard'))
        PWM0_levels   = int(self.getValue('PWM0_settings', 'levels'))
        PWM0_default  = float(self.getValue('PWM0_settings', 'default'))
        self.logger.debug("PWM0 standard = {}".format(PWM0_standard))
        self.logger.debug("PWM0 levels   = {}".format(PWM0_levels))
        self.logger.debug("PWM0 default  = {}".format(PWM0_default))
        # Convert to counts
        value_in_counts = sl.convertPWMVoltsToCounts(PWM0_standard, PWM0_levels, PWM0_default)
        self.logger.debug("Convert PWM Volts to Counts results = {}".format(value_in_counts))
        # Send to FPGA
        self.logger.debug("Sending PWM settings to FPGA")
        sl.set_pwm_settings(PWM0_levels, value_in_counts, bSendToFPGA)
        
        
def main():
    # Create a system parameters object, just for testing:
    sp = SLLSystemParameters()
    sp.saveToFile('test.xml')
    
    rep = sp.tree.find('Reference_frequency')
    print(rep)
    print(rep.attrib['DDC0'])
    
    print(sp.getValue('Reference_frequency', 'DDC0'))
    sp.setValue('Reference_frequency', 'DDC0', '5.1e6')
    print(sp.getValue('Reference_frequency', 'DDC0'))

#    for el in list(sp.root.iter('Default output offset')):
#        print(el)
#        print(el.attrib['DAC0'])
        
    return
    
if __name__ == '__main__':
    main()     