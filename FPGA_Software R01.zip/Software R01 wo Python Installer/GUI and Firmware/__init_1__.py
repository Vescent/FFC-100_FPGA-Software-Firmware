# -*- coding: utf-8 -*-
"""
Created on Fri Feb 16 15:47:30 2018

@author: Dylan Tooley

This script is meant to be a way to run ICE boxes through command line. This will provide the class needed to communicate with ICE.

"""
from serial import *
import time
import numpy as np
import sys, string, os,subprocess
import getopt
from threading import Thread


def valuesfromdict(SN):
    valuesdict={}
    with open('SetValues_SN%s.csv' %SN) as csvdoc:
        data = csvdoc.read().decode("utf-8-sig").encode("utf-8")
        lines = data.split('\n')
        for line in lines:
            elements=line.split(',')
            try:
                key=elements[0]
                value=elements[1]
                valuesdict[key]=value
            except IndexError:
                pass
    for key,value in valuesdict.items():
        if key == 'ICECOM':
            ICECOM=float(value)
        elif key == 'SLICECOM':
            SLICECOM=float(value)
        elif key == 'FCEOCh':        
            FCEOCh=float(value)
        elif key == 'FOPTCh':
            FOPTCh=float(value)
        elif key == 'OscCurrSlot':
            OscCurrSlot=float(value)
        elif key== 'FWSlot':
            FWSlot=float(value)
        elif key == 'BW1Slot':
            BW1Slot=float(value)
        elif key == 'BW2Slot':
            BW2Slot=float(value)
        elif key == 'FWTSlot':
            FWTSlot=float(value)
        elif key == 'BW1TSlot':
            BW1TSlot=float(value)
        elif key== 'BW2TSlot':
            BW2TSlot=float(value)
        elif key == 'FWTCh':
            FWTCh=float(value)
        elif key == 'BW1TCh':
            BW1TCh=float(value)
        elif key == 'BW2TCh':
            BW2TCh=float(value)
        elif key == 'MinCurr':
            MinCurr=float(value)
        elif key== 'MaxCurr':
            MaxCurr=float(value)
        elif key == 'MinTemp':
            MinTemp=float(value)
        elif key == 'MaxTemp':
            MaxTemp=float(value)
        elif key == 'SliceSlot':
            SliceSlot=float(value)
    return ICECOM,SLICECOM,FCEOCh,FOPTCh,OscCurrSlot,FWSlot,BW1Slot,BW2Slot,FWTSlot,BW1TSlot,BW2TSlot,FWTCh,BW1TCh,BW2TCh,MinCurr,MaxCurr,MinTemp,MaxTemp,SliceSlot


class ICE(): 
    
    
    IceTimeout = .1 #Communication Timeout (seconds)
    IceByteRead = 256 #Number of bytes to read on ser.read()
    IceDelay = .01 #Delay in seconds after sending Ice Command to ensure execution
#############################Functions########################    
    def wait(self,num):
        '''Forces program to wait num seconds.
        Note: Shortest Delay--> 1ms'''
        time.sleep(num)    
    
    
    
    def IceSend(self,BoxNum, SlotNum, CommandInput):
        '''Function that sends a serial string command to ICE Box 
        Input: ICE Box Number[int], ICE Slot Number[int], CommandInput[str]
        Output: None (unless print line uncommented)/Read buffer always emptied!
        Note 1: Enter a slot number outside range(1-8) and function sends command directly
        to master board (ex. '#PowerOff' Command)
        Note 2: COM Port is opened/closed each time funciton is run'''
        
        #Open Port w/ ICE COM Default Settings
        IceSer = serial.Serial(port='COM'+str(int(BoxNum)),baudrate=115200,timeout=self.IceTimeout,parity='N',stopbits=1,bytesize=8)
        self.wait(.001)
        
        #Define Command and Send (perform read after each command to maintain synchronicity)
        if int(SlotNum) in range(1,9): #If a Valid Slot Number is input, send command to slot num
            #Define Commands        
            MasterCommand = str('#slave ' + str(int(SlotNum)) + '\r\n')
            SlaveCommand = str(str(CommandInput) + '\r\n')
            
            #Send Commands/Close Port
            IceSer.write(MasterCommand)
            self.wait(self.IceDelay)
            IceOutputSlave = IceSer.read(self.IceByteRead) #Read Buffer
            self.wait(self.IceDelay)
            IceSer.write(SlaveCommand)
            self.wait(self.IceDelay)
            IceOutputReturn = IceSer.read(self.IceByteRead) #Read Buffer
            self.wait(self.IceDelay)
            IceSer.close() #Close COM Port
    
            #Return Output       
            return IceOutputReturn
#            print ' '
#            print 'Master Board Return: ', IceOutputSlave
#            print 'Slave Board Return: ', IceOutputReturn
            
        else: #Command sent only to Master Board (preceding '#', no slot num to specify)
            #Define Command        
            MasterCommand = str('#' + str(CommandInput) + '\r\n')
            
            #Send Commands/Close Port
            IceSer.write(MasterCommand)
            self.wait(self.IceDelay)
            IceOutputReturn = IceSer.read(self.IceByteRead) #Read Buffer
            self.wait(self.IceDelay)
            IceSer.close() #Close COM Port
            
            #Return Output
            return IceOutputReturn
#            print ' '
#            print 'Master Board Return: ', IceOutputReturn
            
class SLICE():
    def SliceSend(self,ComPortNum, CommandInput):
        '''Function that sends a serial string command to SLICE Box 
       Input: Com Port Number[int], CommandInput[str]
	   Output: None (unless print line uncommented)/Read buffer always emptied!
	   Note 1: COM Port is opened/closed each time function is run'''
	#Open Port w/ SLICE COM Default Settings
        SliceTimeout = .1  # Communication Timeout (seconds)
        SliceByteRead = 256  # Number of bytes to read on ser.read()
        SliceDelay = .01  # Delay in seconds after sending Slice Command to ensure execution        
        SliceSer = serialwin32.Serial(port='COM'+str(ComPortNum), baudrate=115200, timeout=1, bytesize=8)
        	#parity=PARITY_NONE, stopbits=STOPBITS_ONE, 
        	#wait(.100)
        	
        	#Define Command and Send (perform read after each command to maintain synchronization)
        	#Define Commands
        	#Command sent only to Master Board (preceding '#', no slot num to specify)
        	#Define Command        
        MasterCommand = str(str(CommandInput) + '\r\n' )     
        #Send Commands/Close Port
        SliceSer.write(MasterCommand.encode())
        #wait(SliceDelay)
        SliceOutputReturn = SliceSer.read(SliceByteRead).decode() #Read Buffer
        #wait(SliceDelay)
        SliceSer.close() #Close COM Port
#        SliceOutputReturn=SliceOutput.translate(None , '\r\n')
        #Return Output
        # 	#print (' ')
        	#print ('Master Board Return: '+ SliceOutputReturn)
        return SliceOutputReturn