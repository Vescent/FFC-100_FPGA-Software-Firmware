"""
XEM6010 Phase-lock box main GUI script,
by JD Deschenes, Octobe
r 2013

"""
import sys
import os
from PyQt4 import QtGui, Qt, QtCore
import numpy as np

import pywintypes
from win32gui import SetWindowPos
import win32con
#import PythonWebServer

import winsound

from SuperLaserLand_JD2 import SuperLaserLand_JD2
from XEM_GUI_MainWindow_v3 import XEM_GUI_MainWindow
#from FreqErrorWindow import FreqErrorWindow
from FreqErrorWindowWithTempControlV2 import FreqErrorWindowWithTempControlV2
#from DisplayPhaseResponseWindow import DisplayPhaseResponseWindow
from DisplayVNAWindow import DisplayVNAWindow
from initialConfiguration import initialConfiguration
from SLLSystemParameters import SLLSystemParameters
from SLLConfigurationWindow import SLLConfigurationWindow

from DisplayTransferFunctionWindow import DisplayTransferFunctionWindow
from DisplayDitherSettingsWindow import DisplayDitherSettingsWindow

from SliceDisplayWindow import *
from DisplayDividerAndResidualsStreamingSettingsWindow import DisplayDividerAndResidualsStreamingSettingsWindow
from DFr_timing_module_settings import DFr_timing_module_settings

import time

#import gc

import allowSetForegroundWindow # This is a workaround to make our window show on top on Windows 7:
#import os   # used by allowSetForegroundWindow()

import logging

# Configure the logger for the main GUI
gui_logger = logging.getLogger("XEM_GUI3")
gui_logger.setLevel(logging.DEBUG)

# Determine where the log files will be saved
if os.path.isdir('./runtime_logs') is False:
    os.mkdir('./runtime_logs')

# Create the root name for this log
date = time.asctime().split(' ')
date_str = '-'.join([date[4], date[1], date[2], date[3].replace(':', '')]) # year, month, day, time
logpath = "./runtime_logs/{}_{}".format(int(time.time()), date_str) # time.time() ensures folders can be sorted by execution order

os.mkdir(logpath)

#Create some file and stream handlers to manage the logger output
#debug_fh = logging.FileHandler(logpath + "/debug.log")
info_fh = logging.FileHandler(logpath + "/info.log")
warning_fh = logging.FileHandler(logpath + "/warnings.log")
error_ch = logging.StreamHandler()

#debug_fh.setLevel(logging.DEBUG)
info_fh.setLevel(logging.INFO)
warning_fh.setLevel(logging.WARNING)
error_ch.setLevel(logging.INFO)

# Create a formatter and set it for each handler
formatter = logging.Formatter('%(asctime)s - %(name)-45s - %(levelname)-8s - %(message)s')
ch_formatter = logging.Formatter('%(name)-30s - %(levelname)-8s - %(message)s')

#debug_fh.setFormatter(formatter)
info_fh.setFormatter(formatter)
warning_fh.setFormatter(formatter)
error_ch.setFormatter(ch_formatter)

# Add our GUI logger to all of the above handlers
#gui_logger.addHandler(debug_fh)
gui_logger.addHandler(info_fh)
gui_logger.addHandler(warning_fh)
gui_logger.addHandler(error_ch)

def main():

    #Announce the start of the program
    gui_logger.info("STARTING MAIN FUNCTION")

    # Create the object that handles the communication with the FPGA board:
    sl = SuperLaserLand_JD2()

    # Specify the mapping between the serial numbers and their colors:
    serial_to_color_mapping = {}
    serial_to_color_mapping['000000054R'] = '#1CC981'
    serial_to_color_mapping['000000054S'] = '#811CC9'
    # serial_to_color_mapping['124300046U'] = 'blue'
    serial_to_color_mapping['12320003SX'] = 'orange'
    serial_to_color_mapping['000000054E'] = '#E37405'   # orange high-bandwidth (dark orange)
    serial_to_color_mapping['000000054J'] = '#70E7FF'  # blue high-bandwidth (light blue)
    serial_to_color_mapping['124300046R'] = '#B572E8'  # purple high-bandwidth (purple)
    serial_to_color_mapping['124300046V'] = '#FF0000'
    serial_to_color_mapping['124300046S'] = '#0033CC'

    # Specify the mapping between the serial numbers and their names:
    serial_to_name_mapping = {}
    serial_to_name_mapping['000000054R'] = 'Box on desk1 (green)'
    serial_to_name_mapping['000000054S'] = 'Box on desk3 (weird purple)'
    # serial_to_name_mapping['124300046U'] = '2nd gen PM comb (blue)'
    serial_to_name_mapping['12320003SX'] = '2nd gen PM comb (orange)'
    serial_to_name_mapping['000000054E'] = 'Wideband orange'   # orange
    serial_to_name_mapping['000000054J'] = 'Wideband blue'   # blue
    serial_to_name_mapping['124300046R'] = 'Wideband purple'   # purple
    serial_to_name_mapping['124300046V'] = 'Amy'
    serial_to_name_mapping['124300046S'] = 'Betts'
    serial_to_name_mapping['124300046U'] = 'VCOtester'
    serial_to_name_mapping['000000054N'] = 'Broken one for PWM test'

    # Add a shorthand for the name so we can add to the window name:  
    serial_to_shorthand_mapping = {}
    serial_to_shorthand_mapping['000000054J'] = 'Blue'   # blue
    serial_to_shorthand_mapping['000000054E'] = 'Orange'   # orange
    serial_to_shorthand_mapping['124300046R'] = 'Purple'   # purple
    serial_to_shorthand_mapping['000000054S'] = 'Weird Purple'
    serial_to_shorthand_mapping['124300046V'] = 'Amy'
    serial_to_shorthand_mapping['124300046S'] = 'Betts'

    serial_to_config_file_mapping = {}
    serial_to_config_file_mapping['000000054J'] = 'system_parameters_synchro_combs.xml'
    serial_to_config_file_mapping['000000054E'] = 'system_parameters_synchro_combs.xml'
    serial_to_config_file_mapping['124300046R'] = 'system_parameters_synchro_combs.xml'
    serial_to_config_file_mapping['124300046V'] = 'system_parameters_garwing_comb_Amy.xml'
    serial_to_config_file_mapping['124300046S'] = 'system_parameters_garwing_comb_Betts.xml'
    serial_to_config_file_mapping['124300046U'] = 'system_parameters_garwing_vcotest.xml'
    serial_to_config_file_mapping['000000054N'] = 'system_parameters_broken_box.xml'


    # Specify the mapping between the serial numbers and the ports that they have to connect to for the temperature control
    # Currentl 50001 is orange, 50002 is blue (hard-coded port numbers in the temperature control script)
    port_number_mapping = {}
    port_number_mapping['124300046U'] = 60002   # blue
    port_number_mapping['12320003SX'] = 60001   # orange
    port_number_mapping['000000054E'] = 60001   # orange (wideband)
    port_number_mapping['000000054J'] = 60002   # blue (wideband)
    port_number_mapping['124300046R'] = 60003   # purple (wideband) #haven't added matching port to temperature control script yet
    port_number_mapping['14370009ME'] = 60001   # Charley's XEM6010



    ###########################################################################
    # Start the User Interface
    allowSetForegroundWindow.allowSetForegroundWindow()

    # Start Qt:
    app = QtGui.QApplication(sys.argv)

    strList = sl.getDeviceList()
    gui_logger.debug("Searching for devices.  Found: {}".format(strList))
    # initial_config = initialConfiguration(strList, serial_to_name_mapping, serial_to_color_mapping, 'superlaserland_v12.bit')
    initial_config = initialConfiguration(strList, serial_to_name_mapping, serial_to_color_mapping, '.')


    # this will remove minimized status 
    # and restore window with keeping maximized/normal state
    allowSetForegroundWindow.allowSetForegroundWindow()
#    initial_config.setWindowState(initial_config.windowState() & ~QtCore.Qt.WindowMinimized | QtCore.Qt.WindowActive)
    # this will activate the window
#    initial_config.activateWindow()
#    initial_config.show()
  #  initial_config.raise_()
  #  initial_config.show()

    SetWindowPos(initial_config.winId(),
                    win32con.HWND_TOPMOST, # = always on top. only reliable way to bring it to the front on windows
                    0, 0, 0, 0,
                    win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW)
    SetWindowPos(initial_config.winId(),
                    win32con.HWND_NOTOPMOST, # disable the always on top, but leave window at its top position
                    0, 0, 0, 0,
                    win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW)
    initial_config.raise_()
    initial_config.show()
    initial_config.activateWindow()

    #initial_config.setWindowState(initial_config.windowState() & ~QtCore.Qt.WindowMinimized | QtCore.Qt.WindowActive)
    # Run the event loop for this window
    app.exec_()
#    print('After app.exec_()()')


    if initial_config.bOk == False:
        # User clicked cancel. simply close the program:
        return

    gui_logger.info("Selected Device Serial #: {}".format(initial_config.strSelectedSerial))
    gui_logger.info("Selected Firmware: {}".format(initial_config.strFirmware))

#    # Fairly dirty hack: if we are using a firmware file which ends in "_highbw.bit", we set the high bandwidth flag to true
#    if initial_config.strFirmware.endswith('_highbw.bit'):
#        sl.bHighBandwidthFilter = True
#    else:
#        sl.bHighBandwidthFilter = False

    bUpdateFPGA = False
    if initial_config.bSendFirmware:

        bUpdateFPGA = True

    # Open the selected FPGA:
    gui_logger.info("Opening selected device")
    error_code = sl.openDevice(initial_config.bSendFirmware, initial_config.strSelectedSerial, initial_config.strFirmware, bUpdateFPGA)

#    error_code = sl.openDevice(initial_config.bSendFirmware, initial_config.strSelectedSerial)
    if error_code != 0:
        gui_logger.error("Unable to open device: error code is {}".format(sl.convertErrorCodeToString(error_code)))
        rep = QtGui.QMessageBox.warning(None, 'Error', sl.convertErrorCodeToString(error_code), QtGui.QMessageBox.Ok)
        return
    else:
        gui_logger.info("Selected device interface opened successfully.")
        gui_logger.debug("Verifying Front Panel is enabled. FrontPanel Enabled? {}".format(sl.dev.IsFrontPanelEnabled()))

    sl.optimize_AD9783_timing()
    ###########################################################################
    # Create the object which handles the configuration parameters (DAC offsets, DAC gains, beat frequency modulation range, etc):
    sp = SLLSystemParameters()
    # Send the values to the FPGA only if we have just re-programmed it. Otherwise we use whatever value is already in so we don't disturb the operation
    bTriggerEvents = False
    if initial_config.bSendFirmware:

        bTriggerEvents = True

    # TODO: Is this code even used?
    # Lookup filename and load if file is there:
    try:
        custom_config_file = serial_to_config_file_mapping[initial_config.strSelectedSerial]
        sp.loadFromFile(custom_config_file)
        gui_logger.info("Loaded configuration for device from {}".format(custom_config_file))
    except KeyError:
        gui_logger.info("No configuration file found for this device.  Will use SLLSystemParameters.py (I THINK?)")
        custom_config_file = ''

    # sp.saveToFile('system_parameters_current.xml')

    bSendToFPGA = bTriggerEvents

    gui_logger.info("Sending configuration to FPGA")
    sp.sendToFPGA(sl, bSendToFPGA)

    gui_logger.info("Building SLL Configuration Window")
    config_window = SLLConfigurationWindow()
    config_window.loadParameters(sp)
    config_window.hide()



    # # This is a hack to start the modelocok before we switch to external clock mode
    # set_dac_offset(self, dac_number, offset)
    # # Output offsets values:
    # output_offset_in_volts = float(self.sp.getValue('Output_offset_in_volts', strDAC))
    # # Scale this to the correct units for the output offset slider:
    # min_output_in_volts = float(self.sp.getValue('Output_limits_low', strDAC))
    # max_output_in_volts = float(self.sp.getValue('Output_limits_high', strDAC))
    # slider_units = (output_offset_in_volts - min_output_in_volts)/(max_output_in_volts-min_output_in_volts) * 1e6
    # print('calling dac offset slider setValue()')
    # self.q_dac_offset[k].blockSignals(True)
    # self.q_dac_offset[k].setValue(slider_units)
    # self.q_dac_offset[k].blockSignals(False)
    # print('done calling dac offset slider setValue()')

#    ###########################################################################
#    # Run a performance test on reading our wires from the FPGA:
#    N_reads = 1
#    start_time = time.clock()
#    sl.measureWireOutsPerformance(N_reads)
#    stop_time = time.clock()
#    print('Reading 1 WireOut: Elapsed time = %f sec\tThroughput = %f reads/sec' % (stop_time-start_time, N_reads/(stop_time-start_time)))
#
#    N_reads = 10
#    start_time = time.clock()
#    sl.measureWireOutsPerformance(N_reads)
#    stop_time = time.clock()
#    print('Reading 1 WireOut: Elapsed time = %f sec\tThroughput = %f reads/sec' % (stop_time-start_time, N_reads/(stop_time-start_time)))
#
#    N_reads = 100
#    start_time = time.clock()
#    sl.measureWireOutsPerformance(N_reads)
#    stop_time = time.clock()
#    print('Reading 1 WireOut: Elapsed time = %f sec\tThroughput = %f reads/sec' % (stop_time-start_time, N_reads/(stop_time-start_time)))
#
#    N_reads = 1000
#    start_time = time.clock()
#    sl.measureWireOutsPerformance(N_reads)
#    stop_time = time.clock()
#    print('Reading 1 WireOut: Elapsed time = %f sec\tThroughput = %f reads/sec' % (stop_time-start_time, N_reads/(stop_time-start_time)))
#



#    trigger_delay = 50
#    boxcar_filter_size = 5
#    rst_residuals_streaming = 1
#    sl.setResidualsStreamingSettings(trigger_delay, boxcar_filter_size, rst_residuals_streaming)
#    rst_residuals_streaming = 0
#    sl.setResidualsStreamingSettings(trigger_delay, boxcar_filter_size, rst_residuals_streaming)


    ############################
    # Set a test pattern on the ADC output:

#    sl.set_LTC2195_spi_register(address=0xA2, register_value=int('00000001', 2))    # default output current, internal termination off, digital outputs are enabled, test pattern OFF, 4-lane output mode
#    sl.set_LTC2195_spi_register(address=0xA2, register_value=int('00000101', 2))    # default output current, internal termination off, digital outputs are enabled, test pattern ON, 4-lane output mode
#    # set all zeros:
#    sl.set_LTC2195_spi_register(address=0xA3, register_value=0)
#    sl.set_LTC2195_spi_register(address=0xA4, register_value=1)


    ###########################################################################
    # Load all our windows:

    # Style sheet which includes the color scheme for each specific box:
    try:
        gui_logger.info("Attempting to look up CSS for this device from serial_to_color_mapping dict.")
        custom_style_sheet = ('#MainWindow {color: white; background-color: %s;}' % serial_to_color_mapping[initial_config.strSelectedSerial])
    except KeyError:
        gui_logger.warning("No CSS mapping found for this device.  Will not load any CSS.")
        custom_style_sheet = ''

    # The shorthand name which gets added to the window names:
    try:
        gui_logger.info("Attempting to look up shorthand name for this device from serial_to_shorthand_mapping dict.")
        custom_shorthand = serial_to_shorthand_mapping[initial_config.strSelectedSerial]
    except KeyError:
        gui_logger.warning("No shorthand name for this device found.  Will not use a nickname for this device.")
        custom_shorthand = ''

    # Have to be careful with the modulus setting (double-check with a scope to make sure the output frequency is right)
    # I think the output frequency for the square wave mode is given by:
    # 200 MHz/(2*(modulus+1))
    # While for the pulsed mode (bPulses = 1), the frequency is:
    # 200 MHz/(modulus+1)
#    sl.set_clk_divider_settings(bOn=1, bPulses=0, modulus=67e3-1)
#    sl.set_clk_divider_settings(bOn=1, bPulses=0, modulus=67e3+1-1)
    gui_logger.info("Building DisplayDividerAndResidualsStreamingSettings Window")
    divider_settings_window = DisplayDividerAndResidualsStreamingSettingsWindow(sl, clk_divider_modulus=67e3, bDividerOn=0, bPulses=0, custom_style_sheet=custom_style_sheet, custom_shorthand=custom_shorthand, bUpdateFPGA = bSendToFPGA)



    # Optical lock window
    gui_logger.info("Building Optical Lock Window")
    xem_gui_mainwindow2 = XEM_GUI_MainWindow(sl, custom_shorthand + ': Optical lock', 1, (False, True, True), sp, custom_style_sheet, initial_config.strSelectedSerial)
    xem_gui_mainwindow2.initSL(bTriggerEvents)

    # CEO Lock window
    gui_logger.info("Building CEO Lock Window")
    xem_gui_mainwindow = XEM_GUI_MainWindow(sl, custom_shorthand + ': CEO lock', 0, (True, False, False), sp, custom_style_sheet, initial_config.strSelectedSerial)
    xem_gui_mainwindow.initSL(bTriggerEvents)



    #########################################################
    # The dfr trigger settings, just for debugging:
#    fake_mode_number = 1e6
#    sl.set_dfr(fbeat1=25e6+10*fake_mode_number, fbeat2=25e6, fceo1=25e6, fceo2=25e6)
#    sl.set_dfr_modulus(mode_number=fake_mode_number)
    #FEATURE
    #dfr_timing_gui = DFr_timing_module_settings(sl, custom_style_sheet, custom_shorthand=custom_shorthand)
#    set_dfr_modulus

    # The two frequency counter:
    strOfTime = time.strftime("%m_%d_%Y_%H_%M_%S_")

    try:
        gui_logger.info("Looking up temp control port from port number mapping")
        temp_control_port = port_number_mapping[initial_config.strSelectedSerial]
    except KeyError:
        gui_logger.warning("Temperature Control Port mapping not found for this device.  Defaulting to port 0.")
        temp_control_port = 0


    strNameTemplate = 'data_logging\%s' % strOfTime
    strNameTemplate = '%s_%s_' % (strNameTemplate, initial_config.strSelectedSerial)
    gui_logger.info("Building FreqError Window with Temp Control w/ CEO and Optical beat in-loop counters")
    freq_error_window1 = FreqErrorWindowWithTempControlV2(sl, 'CEO beat in-loop counter', 0, strNameTemplate, custom_style_sheet, 0, xem_gui_mainwindow)
    freq_error_window2 = FreqErrorWindowWithTempControlV2(sl, 'Optical beat in-loop counter', 1, strNameTemplate, custom_style_sheet, temp_control_port, None)

    counters_window = Qt.QWidget()
    counters_window.setObjectName('MainWindow')
    counters_window.setStyleSheet(custom_style_sheet)
    vbox = Qt.QVBoxLayout()
    vbox.addWidget(freq_error_window1)
    vbox.addWidget(freq_error_window2)
    counters_window.setLayout(vbox)
    counters_window.setWindowTitle(custom_shorthand + ': Frequency counters')
    #counters_window.setGeometry(993, 40, 800, 1010)
    #counters_window.setGeometry(0, 0, 750, 1000)
#    counters_window.resize(600, 1080-100+30)
    counters_window.move(QtGui.QDesktopWidget().availableGeometry().topLeft() + Qt.QPoint(985, 10))
    counters_window.show()

    # Dither windows, this code could be moved to another class/file to help with clutter:
    gui_logger.info("Building Dither Widgets")
    dither_widget0 = DisplayDitherSettingsWindow(sl, 0, modulation_frequency_in_hz='1.1e3', output_amplitude='4e-4', integration_time_in_seconds='0.1', bEnableDither=True, custom_style_sheet=custom_style_sheet)
    dither_widget1 = DisplayDitherSettingsWindow(sl, 1, modulation_frequency_in_hz='5e3',   output_amplitude='1e-3', integration_time_in_seconds='0.1', bEnableDither=True, custom_style_sheet=custom_style_sheet)
    dither_widget2 = DisplayDitherSettingsWindow(sl, 2, modulation_frequency_in_hz='100',   output_amplitude='1e-4', integration_time_in_seconds='0.1', bEnableDither=True, custom_style_sheet=custom_style_sheet)

    dither_window = Qt.QWidget()
    dither_window.setObjectName('MainWindow')
    dither_window.setStyleSheet(custom_style_sheet)
    vbox = Qt.QVBoxLayout()
    vbox.addWidget(dither_widget0)
    vbox.addWidget(dither_widget1)
    vbox.addWidget(dither_widget2)
    dither_window.setLayout(vbox)
    dither_window.setWindowTitle(custom_shorthand + ': Dither controls')
    dither_window.show()
#    # SLICE windows, this code could be moved to another class/file to help with clutter:
    gui_logger.info("Building SLICE Widgets")
    SliceWidget = DisplaySliceWindow(sl, custom_style_sheet=custom_style_sheet)

    Slice_window = Qt.QWidget()
    Slice_window.setObjectName('MainWindow')
    Slice_window.setStyleSheet(custom_style_sheet)
    vbox = Qt.QVBoxLayout()
    vbox.addWidget(SliceWidget)
    Slice_window.setLayout(vbox)
    Slice_window.setWindowTitle(custom_shorthand + ': SLICE Controls')
    Slice_window.show()                                                                                           
#
#
#    ###########################################################################
#    # Create another log file which indicates which FPGA generated these logs:
#    # FreqErrorWindow() should have made sure that the data_logging folder exists:
#    strCurrentName = strNameTemplate + 'info.txt'
#    file_output_info = open(strCurrentName, 'w')
#    file_output_info.write('XEM_GUI3.py started on %s.\n' % strOfTime)
#    file_output_info.write('FPGA serial number = %s\n' % initial_config.strSelectedSerial)
#    try:
#        file_output_info.write('FPGA name = %s\n' % serial_to_name_mapping[initial_config.strSelectedSerial])
#    except KeyError:
#        file_output_info.write('FPGA name = \n')
#    try:
#        file_output_info.write('FPGA color = %s\n' % serial_to_color_mapping[initial_config.strSelectedSerial])
#    except KeyError:
#        file_output_info.write('FPGA color = \n')
#    file_output_info.close()

#    ###########################################################################
#    # For testing out the transfer function window:
#    frequency_axis = np.logspace(np.log10(10e3), np.log10(2e6), 10e3)
#    transfer_function = 1/(1 + 1j*frequency_axis/100e3)
#    window_number = 1
#    vertical_units = 'V/V'
#    tf_window1 = DisplayTransferFunctionWindow(frequency_axis, transfer_function, window_number, vertical_units)
#

#    # Regroup the two windows into a single one:
    main_windows = Qt.QWidget()
    main_windows.setObjectName('MainWindow')
    main_windows.setStyleSheet(custom_style_sheet)


    ###########################################################################
    # Select clock source
    # clock_source = 0: Internal clock at 100 MHz
    # clock_source = 1: External clock at 200 MHz on DIN[0]/CLKIN, divided by 2 internally for a system clock still at 100 MHz
    if initial_config.bSendFirmware:
        if initial_config.bExternalClock == True:
            clock_source = 1
            gui_logger.info("Using EXternal clock mode")
        else:
            clock_source = 0
            gui_logger.info("Using Internal clock mode")
        sl.selectClockSource(clock_source)
        # Now we just need to reset the frontend to make sure we start everything in a nice state
        sl.resetFrontend()



    tabs = QtGui.QTabWidget()
    # xem_gui_mainwindow2.resize(600, 700)

    # xem_gui_mainwindow.setContentsMargins(0, 0, 0, 0)
    # xem_gui_mainwindow.layout().setContentsMargins(0, 0, 0, 0)
    # xem_gui_mainwindow2.setContentsMargins(0, 0, 0, 0)
    # xem_gui_mainwindow2.layout().setContentsMargins(0, 0, 0, 0)
    # counters_window.setContentsMargins(0, 0, 0, 0)
    # counters_window.layout().setContentsMargins(0, 0, 0, 0)
    # dither_window.setContentsMargins(0, 0, 0, 0)
    # dither_window.layout().setContentsMargins(0, 0, 0, 0)
    # dfr_timing_gui.setContentsMargins(0, 0, 0, 0)
    # dfr_timing_gui.layout().setContentsMargins(0, 0, 0, 0)
    # divider_settings_window.setContentsMargins(0, 0, 0, 0)
    # divider_settings_window.layout().setContentsMargins(0, 0, 0, 0)

    tabs.setMaximumSize(1920,1080-100+30)
    # main_windows.setMaximumSize(600,600)
    # xem_gui_mainwindow.setMaximumSize(600,600)
    # xem_gui_mainwindow2.setMaximumSize(600,600)
    # counters_window.setMaximumSize(600,600)
    # dither_window.setMaximumSize(600,600)
    # dfr_timing_gui.setMaximumSize(600,600)
    # divider_settings_window.setMaximumSize(600,600)
    gui_logger.info("Consolidating created widgets and applets into one window.")
    tabs.addTab(xem_gui_mainwindow, "CEO Lock")
    tabs.addTab(xem_gui_mainwindow2, "Optical Lock")
    tabs.addTab(counters_window, "Counters")
    tabs.addTab(dither_window, "Dither")
    tabs.addTab(Slice_window, 'Slow Loop')
    #FEATURE
    #tabs.addTab(dfr_timing_gui, "DFr trigger generator")
    tabs.addTab(divider_settings_window, "Filter settings")
    # tabs.setGeometry(0, 0, 750, 1000)

    tab_scroll_area = QtGui.QScrollArea()
    tab_scroll_area.setWidget(tabs)

    box = QtGui.QHBoxLayout()
    box.addWidget(tab_scroll_area)
    main_windows.setLayout(box)
    main_windows.setWindowTitle(custom_shorthand)
    # main_windows.setContentsMargins(0, 0, 0, 0)
    # main_windows.layout().setContentsMargins(0, 0, 0, 0)

    # main_windows.setGeometry(0, 30, 1366, 700)
    main_windows.showMaximized()
    # main_windows.resize(600, 700)
    # main_windows.move(QtGui.QDesktopWidget().availableGeometry().topLeft() + Qt.QPoint(0, 0))

    main_windows.show()

#    hbox = Qt.QHBoxLayout()
#    hbox.addWidget(xem_gui_mainwindow)
#    hbox.addWidget(xem_gui_mainwindow2)
#    main_windows.setLayout(hbox)
#    main_windows.setWindowTitle('Phase-lock controls')
##    main_windows.setGeometry(993, 40, 800, 1010)
##    main_windows.resize(600, 1080-100+30)
##    main_windows.move(QtGui.QDesktopWidget().availableGeometry().topLeft() + Qt.QPoint(985, 10))
#    main_windows.show()


    # Enter main event loop
    gui_logger.info("Executing application window")
    app.exec_()
#    del xem_gui_mainwindow
#    del sl
    

if __name__ == '__main__':
    main()     
    
    