
"""
Created on Fri Mar 20 11:45:25 2020

@author: dylan
"""

"""
XEM6010 Phase-lock box GUI, SLICE settings controls
by DT @Vescent Photonics March 2020

"""

import time
from PyQt4 import QtGui, Qt
import PyQt4.Qwt5 as Qwt
import numpy as np
import serial#,list_ports
import weakref
from SuperLaserLand_JD2 import SuperLaserLand_JD2
import subprocess
import os
from os import system

class DisplaySliceWindow(QtGui.QWidget):
        
    def __init__(self, sl, custom_style_sheet=''):
        super(DisplaySliceWindow, self).__init__()
        

        
        self.sl = weakref.proxy(sl)
        self.setObjectName('MainWindow')
        self.setStyleSheet(custom_style_sheet)
        
        
        self.initUI(TempSet=25, TError=0.1, VoltageOutput=50, CurrentSet=300, CurrentModLvl=0, bCurrentSlowLoop=False, bTempSlowLoop=False)
        

        
       
 	
        
    def readSliceSettings(self, Command):
        Setting = self.Send(COM,Command)
        return Setting
       
    def setSliceSettings(self, Command):    
        setvalue = self.Send(COM,Command)
        return setvalue
        


    def TempLoopClicked(self):
        FrequencyCombCOM=self.qdisp_FFCCom.text()
        self.TempSlowLoop(FrequencyCombCOM)

            
        
    
    def CurrentLoopClicked(self):
        if self.qbtn_SlowLoopCurr == False:
            self.qbtn_SlowLoopCurr = True
            self.FrequencyCombCOM=self.qdisp_FFCCom.text()
            self.CurrSlowLoop(self.FrequencyCombCOM)
        elif self.qbtn_SlowLoopCurr == True:
            self.qbtn_SlowLoopCurr = False
        
#    def CurrSlowLoop(self,FFCCom):
 #       os.startfile("python SlowLoopsCurr_FFC.py %s" %('-f '+str(FFCCom)))
   
    def TempSlowLoop(self,FFCCom):
	command = "python SlowLoopsTemp_FFC.py %s %s" %("-f" + str(FFCCom), "-h" + str(self.qdisp_TempVoltIntSet.text()))
        os.system('start cmd /k %s' %command)
       
        
        
        
    def initUI(self, TempSet, TError, VoltageOutput, CurrentSet, CurrentModLvl, bCurrentSlowLoop, bTempSlowLoop):

        # Create the widgets which control the Slice feedback module:


        ######################################################################
        # Settings

#    	ports = list(list_ports.comports())
#         p in ports:
#             self.Message(str(p),'#MODEL')
#		     if model == '11' : self.QtcComSetting = p
#		     if model == '12' : self.HVComSetting = p
#		     if model == '13' : self.DCCComSetting = p
#		     if model == '23' : self.QtcComSetting = p, self.HVComSetting = p, self.DCCComSetting = p

        ######################################################################

        self.qgroupbox_Slice = Qt.QGroupBox('Slow Loop Settings')
        self.qgroupbox_Slice.setAutoFillBackground(True)
        
        
        # Temperature Set:
        self.qdisp_Temp_label = Qt.QLabel('Oscillator Temperature Setpoint [C]:')
        self.qdisp_TemperatureSet = Qt.QLineEdit(str(TempSet))
        self.qdisp_TemperatureSet.setMaximumWidth(60)
        self.qdisp_TemperatureSet.setReadOnly(1)
        
        
#        # Temperature Error:
#        self.qdisp_TempError_label = Qt.QLabel('Oscillator Temperature Error [mK]:')
#        self.qdisp_TemperatureError = Qt.QLineEdit(str(TError))
#        self.qdisp_TemperatureError.setMaximumWidth(60)
#        self.qdisp_TemperatureError.setReadOnly(1)
#        
#        # Voltage Out:
#        self.qdisp_VoltageOut_label = Qt.QLabel('Voltage Out [V]:')
#        self.qdisp_VoltageOut = Qt.QLineEdit(str(VoltageOutput))
#        self.qdisp_VoltageOut.setMaximumWidth(60)
#        self.qdisp_VoltageOut.setReadOnly(1)
        
        # Current Set:
        self.qdisp_Curr_label = Qt.QLabel('Oscillator Current Setpoint [mA]:')
        self.qdisp_CurrSet = Qt.QLineEdit(str(CurrentSet))
        self.qdisp_CurrSet.setMaximumWidth(60)
        self.qdisp_CurrSet.setReadOnly(1)
        
#        # On/Off button Temperature Slow Loop 
        self.qbtn_SlowLoopTemp = QtGui.QPushButton('Activate Temperature Slow Loop')
        self.qbtn_SlowLoopTemp.clicked.connect(self.TempLoopClicked)
        self.qbtn_SlowLoopTemp.setCheckable(False)
#        self.qbtn_SlowLoopTemp.setChecked(bool(bTempSlowLoop))
	       

        # On/Off button Current Slow Loop 
        self.qbtn_SlowLoopCurr = QtGui.QPushButton('Activate Current Slow Loop')
        self.qbtn_SlowLoopCurr.clicked.connect(self.CurrentLoopClicked)
        self.qbtn_SlowLoopCurr.setCheckable(False)
#        self.qbtn_SlowLoopCurr.setChecked(bool(bCurrentSlowLoop))


###FFC COM Port###
        self.qdisp_FFCCom_label = Qt.QLabel('FFC COM Port:')
        try:
        	self.qdisp_FFCCom = Qt.QLineEdit(str(self.FFCComSetting))
        except:
            self.qdisp_FFCCom = Qt.QLineEdit('')
        self.qdisp_FFCCom.setMaximumWidth(60)    
        
        
        # Slice QTC Comport
#        self.qdisp_QtcCom_label = Qt.QLabel('QTC Comport:')
#	    try:
#        	self.qdisp_QtcCom = Qt.QLineEdit(str(self.QtcComSetting))
#        except:
#		    self.qdisp_QtcCom = Qt.QLineEdit('')
#	    self.qdisp_QtcCom.setMaximumWidth(60)
        
#        # Slice QTC Channel
#        self.qdisp_QtcChan_label = Qt.QLabel('QTC Channel:')
#        self.qdisp_QtcChan = Qt.QLineEdit(str(1))
#        self.qdisp_QtcChan.setMaximumWidth(60)
        
        # Slice DHV Comport
        self.qdisp_DHVCom_label = Qt.QLabel('')
#	try:
 #       	self.qdisp_DHVCom = Qt.QLineEdit(str(self.HVComSetting))
#        except: 
#		self.qdisp_DHVCom = Qt.QLineEdit('')
#	self.qdisp_DHVCom.setMaximumWidth(60)
#        
        # Slice DHV Channel
#        self.qdisp_DHVChan_label = Qt.QLabel('')
#        self.qdisp_DHVChan = Qt.QLineEdit(str(1))
#        self.qdisp_DHVChan.setMaximumWidth(60)
#        
#        # Slice DCC Comport
        self.qdisp_DCCCom_label = Qt.QLabel('')
#	try:
#        	self.qdisp_DCCCom = Qt.QLineEdit(str(self.DCCComSetting))
#        except:
#		self.qdisp_DCCCom = Qt.QLineEdit('')
#	self.qdisp_DCCCom.setMaximumWidth(60)
#        
#        # Slice DCC Channel
#        self.qdisp_DCCChan_label = Qt.QLabel('DCC Channel:')
#        self.qdisp_DCCChan = Qt.QLineEdit(str(1))
#        self.qdisp_DCCChan.setMaximumWidth(60)
        
        
        # Temp Integrator Voltage Target Set
        self.qdisp_TempVoltIntSet_label = Qt.QLabel('PZT Setpoint [0-100V]:')
        self.qdisp_TempVoltIntSet = Qt.QLineEdit(str(50))
        self.qdisp_TempVoltIntSet.setMaximumWidth(60)
        
        # Put all the widgets into a grid layout
        grid = QtGui.QGridLayout()
        grid.setHorizontalSpacing(1000)

#        grid.addWidget(self.qdisp_Temp_label,               1, 0)
#        grid.addWidget(self.qdisp_TemperatureSet,           1, 1)
#        grid.addWidget(self.qdisp_TempError_label,          1, 0)
#        grid.addWidget(self.qdisp_TemperatureError,         1, 1)        
#        
#        grid.addWidget(self.qdisp_VoltageOut_label,         2, 0)
#        grid.addWidget(self.qdisp_VoltageOut,               2, 1)
#        

#        grid.addWidget(self.qdisp_Curr_label,               2, 0)
#        grid.addWidget(self.qdisp_CurrSet,                  2, 1)
        
#        grid.addWidget(self.qbtn_SlowLoopCurr,              2, 1)


        grid.addWidget(self.qbtn_SlowLoopTemp,              0, 0, 1, 2)
        grid.addWidget(self.qdisp_TempVoltIntSet_label,     2, 0, 1, 1)
        grid.addWidget(self.qdisp_TempVoltIntSet,           2, 1, 1, 1)

	grid.addWidget(self.qdisp_FFCCom,                   1, 1, 1, 1)
	grid.addWidget(self.qdisp_FFCCom_label,             1, 0, 1, 1)


#        grid.addWidget(self.qdisp_QtcCom,                   5, 1)        
#        grid.addWidget(self.qdisp_QtcCom_label,             5, 0)
#        grid.addWidget(self.qdisp_QtcCom,                   5, 1)
#        grid.addWidget(self.qdisp_QtcChan_label,            5, 2)
#        grid.addWidget(self.qdisp_QtcChan,                  5, 3)
#        grid.addWidget(self.qdisp_DHVCom_label,             0, 2, 3, 1)
#        grid.addWidget(self.qdisp_DHVCom,                   6, 1)
#        grid.addWidget(self.qdisp_DHVChan_label,            6, 2)
#        grid.addWidget(self.qdisp_DHVChan,                  6, 3)
#        grid.addWidget(self.qdisp_DCCCom_label,             1,3, 1, 1)
#        grid.addWidget(self.qdisp_DCCCom,                   7, 1)
#        grid.addWidget(self.qdisp_DCCChan_label,            7, 2)
#        grid.addWidget(self.qdisp_DCCChan,                  7, 3)
        
        self.qgroupbox_Slice.setLayout(grid)    

        vbox = Qt.QVBoxLayout()
        vbox.addWidget(self.qgroupbox_Slice)
        self.setLayout(vbox)
        

        # Adjust the size and position of the window
#        self.resize(800, 600)
        self.center()
        self.setWindowTitle('Slice Control')    
        self.show()
        

        
    def center(self):
        
        qr = self.frameGeometry()
        cp = QtGui.QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
#        self.move(qr.topLeft())
#        self.move(QtGui.QDesktopWidget().availableGeometry().topLeft() + Qt.QPoint(50, 50))
        



    

    def Open(self, portNameStr):

        '''Opens a serial port that is named portNameStr. Must call before using Send command.'''

        self.portRef = serial.Serial(port = portNameStr, baudrate = 11520, timeout = 1.0, bytesize = 8)

    def Close(self):

        '''Closes the serial port. Must call before ending program to properly shut down SLICE comms.'''

        self.portRef.close()  

    def Send(self, messageStr):

        '''Sends the message command string messageStr to the serial port.

        Terminates messageStr with a carriage return character.

        Returns the message response string from the input command.

        Does NOT automatically open the serial port. Invoke Open method before calling this method.

        Does NOT automatically close the serial port. Invoke Close method to do so.'''

        numBytesToRead = 256

        terminationStr = '\r'

        self.portRef.write( (messageStr + terminationStr).encode() )

        return self.portRef.read(numBytesToRead).decode()

    def Message(self, portNameStr, messageStr):

        '''Opens serial port named portNameStr, sends messageStr, and then closes serial port. 

        Does not require Open and Close methods be called before and after sending this command.'''

        self.Open(portNameStr)

        retStr = self.Send(messageStr)

        self.Close()

        return retStr        
        
        