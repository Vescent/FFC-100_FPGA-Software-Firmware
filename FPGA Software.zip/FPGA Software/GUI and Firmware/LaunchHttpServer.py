import threading
import time
import PythonWebServer


class http_server_thread(object):
    """ Threading example class
    The run() method will be started and it will run in the background
    until the application exits.
    """

    def __init__(self, interval=10):
        """ Constructor
        :type interval: int
        :param interval: Check interval, in seconds
        """
        self.interval = interval

        thread = threading.Thread(target=self.run, args=())
        thread.daemon = True                            # Daemonize thread
        thread.start()                                  # Start the execution

    def run(self):
        """ Method that runs forever """
        a = PythonWebServer.run()
        print "started WebServer thread"
        while True:
            # Do something
            print('WebServer Check')

            time.sleep(self.interval)

def run():
    example = http_server_thread()
    #while True:
    #    time.sleep(200)
    print('Http server launched')
