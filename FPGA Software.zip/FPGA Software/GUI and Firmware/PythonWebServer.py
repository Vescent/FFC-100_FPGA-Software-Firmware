#!/usr/bin/env python
"""
Very simple HTTP server in python.

https://gist.github.com/bradmontgomery/2219997#file-dummy-web-server-py

Usage::
    ./dummy-web-server.py [<port>]

Send a GET request::
    curl http://localhost

Send a HEAD request::
    curl -I http://localhost

Send a POST request::
    curl -d "foo=bar&bin=baz" http://localhost

"""
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import SocketServer
import time, threading, sys

count = 10
DAC0data = "NONE"
DAC1data = "NONE"
DAC2data = "NONE"
class WebServer(BaseHTTPRequestHandler):

    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def do_GET(self):
        global count
        self._set_headers()
        self.wfile.write("DAC0,1,2 count: "+str(count)+" Data: "+"/n"+DAC0data + "/n" + DAC1data + "/n" + DAC2data)
        count = count + 1

    def do_HEAD(self):
        self._set_headers()
        
    def do_POST(self):
        # Doesn't do anything with posted data
        self._set_headers()
        self.wfile.write("<html><body><h1>POST!</h1></body></html>")
        
def run(server_class=HTTPServer, port=80):
    server_address = ('', port)
    httpd = server_class(server_address, WebServer)
    print 'Starting httpd server...'
    httpd.serve_forever()

#    def __init__(self):
#        self.run()
