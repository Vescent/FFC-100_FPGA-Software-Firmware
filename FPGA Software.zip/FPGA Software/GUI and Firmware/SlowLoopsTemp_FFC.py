# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 09:45:21 2019

@author: Dylan.Tooley
"""
import os
from __init_1__ import *
import getopt
#def comfind(): ##This is not implemented. Wanted to find comport for user, but need more time.
#    import serial.tools.list_ports; comlist=([comport.device for comport in serial.tools.list_ports.comports()])
#    for comporter in comlist: comporter.strip('u')
#    print comlist
def makefolder(newpath):
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    return newpath


def slowloops(SB,FFCCom,HVSetpoint,cd):


    print 'The purpose of this program is to measure the PZT voltage and feedback with a temperature correction to keep the voltage centered.'
    
    
    ##  Set Parameters for loop###    
    intGain=0.00012#Degree C per volt.  Assuming 3 s update time.

    VoltageSetPoint = float(HVSetpoint)
    
    MaxTemp = 50
    MinTemp = 10
    
    PrevVoltageError=0

    OscTemp = float(SB.SliceSend(FFCCom ,  "CATSETP? %s" ).strip('CATSETP?'))
    print 'initial Fiber oven setpoint: ' + str(OscTemp) + " degree C"

    loop = 1
    try:
        while True:
            #####################  Execute Slow Loop##################'
            try:
                MonitorVoltage = float(SB.SliceSend(FFCCom, 'CADCBV?').strip('CADCBV?'))#read monitor voltage given to slice
                print 'Voltage to PZT = %s' %MonitorVoltage#lets the user know what is read
                VoltageError=VoltageSetPoint-MonitorVoltage#calculate error
                PrevVoltageError = VoltageError#save voltage just incase error on next loop occurs, we can still run
            
            except KeyboardInterrupt:#lets user exit during this try statement
                print 'Loop ended.'
                break
            except Exception as error:#error handling so the loop doesn't crash with a bad reading
                print str(error) + '\n Loop is still running'
                VoltageError = PrevVoltageError
                pass
            loop += 1


        
           
            OscTemp = OscTemp+intGain*VoltageError##Update integral value
            
            if OscTemp>MinTemp and OscTemp<MaxTemp:
                OscTempUpdated = SB.SliceSend(FFCCom, "CATSETP %s" %str(OscTemp).strip('CATSETP?'))
                print('Update')
            if OscTemp<MinTemp:
                print ("Oscillator temperature too low, cannot update")
                OscTempUpdated = SB.SliceSend(FFCCom, "CATSETP %s" %(str(MinTemp)))
            if OscTemp > MaxTemp:
                print ("Oscillator temperature too high, cannot update")
                OscTempUpdated = SB.SliceSend(FFCCom, "CATSETP %s" %str(MaxTemp))
            print "New fiber Oven Temperature " + str(OscTempUpdated) + " degree C"


            time.sleep(1)
            
            ###Save Data to File###
            monitorvoltagelogger=open('\\'.join([cd,'MonitorVoltageLog.csv']),'a+')
            tempsetpointlogger=open('\\'.join([cd,'TempSetPointLog.csv']),'a+')
            
            monitorvoltagelogger.write(','.join([str(time.time()),str(VoltageError),'\n']))
            tempsetpointlogger.write(','.join([str(time.time()),str(OscTemp),'\n']))

            monitorvoltagelogger.close()
            tempsetpointlogger.close()
        #############################    End of SLow Loop    ##########################

    except KeyboardInterrupt:
        print 'Loop ended.'
        pass
def _main(argv):
    
    try:
        opts, args = getopt.getopt(argv, "f:h:", ["FFCCom=" , "HVSetpoint=" ])
    except:
        _input('Could not get FFCCom, please input:')
        _input('HVSetpoint?')

    for opt , arg in opts:
        if opt in ('-f' , '--FFCCom'):
            FFCCom=arg
        if opt in ('-h' , '--HVSetpoint'):
            HVSetpoint=arg	
     ##set up Slice##
    SB=SLICE()
     
    ##Run slow loop##
    slowloops(SB, FFCCom, HVSetpoint, os.getcwd())
    

   
if __name__ == "__main__":
     ##Set up logging###
    firsttime = 1  # to make only 1 folder for logging loop
    loggingdirectory=makefolder('\\'.join([os.getcwd(),'logging',time.strftime("%Y-%m-%d_%H-%M-%S")]))
    readmefile=open('\\'.join([loggingdirectory,'README.txt']), 'w+')
    readmefile.write('The files in this directory are CSV files with slow servo voltages and setpoints saved. The first column is the time the logging event occured. The second column consists of the data taken from the NIST Oscillator box. ')
    readmefile.close()
    
    _main(sys.argv[1:])    
    
   
